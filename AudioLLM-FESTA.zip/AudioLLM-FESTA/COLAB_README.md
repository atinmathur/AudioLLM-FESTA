# FESTA for Google Colab

This package contains a lightweight version of FESTA for quick testing on Google Colab.

## What's Included

- **Code**: All source code, experiments, and notebooks
- **Mini Dataset**: 15 samples (5 per task) instead of full 620 samples
- **Configuration**: Pre-configured for Colab with quick test settings

## Size

- **This package**: ~25-30 MB
- **Full dataset**: ~908 MB
- **Size reduction**: ~97%

## Quick Start

1. **Upload to Colab**: Upload `AudioLLM-FESTA-colab.zip`
2. **Open notebook**: Open `notebooks/colab_festa.ipynb`
3. **Run all cells**: Runtime → Run all
4. **Wait ~10-15 minutes**: Complete experiment

## What You'll Get

- FESTA uncertainty scores
- Baseline comparisons
- AUROC metrics (~0.70-0.85 expected)
- Visualization plots

## Limitations

- Only 15 samples (vs 90 in full dataset)
- Results may vary due to small sample size
- Use for testing/verification, not final evaluation

## Scaling Up

To run full experiments later:

**Option 1**: Upload to Google Drive
```python
from google.colab import drive
drive.mount('/content/drive')
# Upload full TREA_dataset to Drive
```

**Option 2**: Generate larger mini dataset
```bash
# In create_mini_dataset.py, change:
SAMPLES_PER_TASK = 30
```

## Documentation

- `README.md` - Full project documentation
- `COLAB_INSTRUCTIONS.md` - Detailed Colab setup guide
- `QUICK_START.md` - Quick start guide

## Support

For issues or questions, see COLAB_INSTRUCTIONS.md

---

**Generated**: 2025-10-25 10:21:00
**Package size**: Will be shown after creation
